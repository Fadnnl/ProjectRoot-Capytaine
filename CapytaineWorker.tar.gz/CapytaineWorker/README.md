# 📘 Capytaine Worker

Worker service berbasis **FastAPI + Capytaine** untuk simulasi sederhana floating body (contoh sphere).  
Service ini dibuat agar bisa di-loadtest menggunakan **Go Test Runner** (oleh tim lain).

---

## 🚀 Features
- REST API berbasis FastAPI
- Generate sphere mesh dengan Capytaine
- Expose info mesh, DOFs, dan bounding box
- Siap di-deploy dengan Docker

---

## 📂 Struktur Folder
CapytaineWorker/
├─ app/
│ ├─ init.py
│ ├─ main.py # FastAPI API definition
│ └─ capy_runner.py # Capytaine helper functions
├─ requirements.txt # Python dependencies
├─ Dockerfile # Docker build
└─ docker-compose.yml # Service orchestration

yaml
Copy
Edit

---

## ⚙️ Installation & Run

### 1. Build & Run via Docker Compose
```sh
docker compose build
docker compose up -d
Cek container:

sh
Copy
Edit
docker ps
2. Local Debug (tanpa Docker)
sh
Copy
Edit
python -m venv .venv
.\.venv\Scripts\activate   # (Windows)
pip install -r requirements.txt
uvicorn app.main:app --reload
Akses di:
👉 http://127.0.0.1:8000

🔗 API Endpoints
✅ Health Check
GET /healthz

Response:

json
Copy
Edit
{
  "status": "ok",
  "service": "capytaine-worker"
}
🌀 Simulate Sphere
POST /simulate
Content-Type: application/json

Request
json
Copy
Edit
{
  "name": "MySphere",
  "radius": 1.0,
  "heave_only": true
}
Response
json
Copy
Edit
{
  "status": "ok",
  "result": {
    "name": "MySphere",
    "nb_faces": 400,
    "nb_vertices": 382,
    "dofs": ["Heave"],
    "bbox": {
      "xmin": -1.0,
      "ymin": -1.0,
      "zmin": -1.0,
      "xmax": 1.0,
      "ymax": 1.0,
      "zmax": 1.0
    }
  }
}
📊 Integration with Go Test Runner
Repo ini hanya menyediakan Python Worker (Capytaine).

Tim lain (contoh: Dildilll) akan membuat Go Test Runner di host machine untuk:

Menembak endpoint /simulate

Mengukur latency, RPS, error rate

Membandingkan hasil dengan WaveCore

📌 Next Steps
 Tambah endpoint simulate_radiation untuk komputasi BEM (added mass, damping).

 Tambah logging & monitoring.

 Integrasi metrics ke StatsD/Graphite.

👥 Team
Author (Python Worker): Mubaroq Dwiki Husni Farhan

Collaborator (Go Test Runner): Dildilll

📝 License
Project ini mengikuti lisensi dari Capytaine (GPL v3).