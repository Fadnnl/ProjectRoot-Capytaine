# runner.py
import argparse
import asyncio
import httpx
import time


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--url",
        type=str,
        required=True,
        help="Target Worker URL (e.g. http://localhost:8000/start-test)",
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=10,
        help="Jumlah iterasi simulasi yang akan dijalankan di worker",
    )
    parser.add_argument(
        "--test_file",
        type=str,
        default="pytest/test_diffraction.py",
        help="File pytest yang akan dieksekusi di worker",
    )
    args = parser.parse_args()

    async with httpx.AsyncClient(timeout=None) as client:
        print(f"Triggering worker at {args.url} with {args.iterations} iterations ...")
        start_time = time.time()

        try:
            resp = await client.post(
                args.url,
                json={"iterations": args.iterations, "test_file": args.test_file},
            )
            duration = time.time() - start_time

            if resp.status_code == 200:
                data = resp.json()
                print("[Worker Response]")
                print(data)
                print(f"Total Duration (including request): {duration:.3f}s")
            else:
                print(f"Error {resp.status_code}: {resp.text}")

        except Exception as e:
            print(f"Failed to trigger worker: {e}")


if __name__ == "__main__":
    asyncio.run(main())
