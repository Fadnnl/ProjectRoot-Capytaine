package main

import (
	"bytes"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"os/signal"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
)

type sliceFlag []string

func (s *sliceFlag) String() string { return strings.Join(*s, ",") }
func (s *sliceFlag) Set(v string) error {
	*s = append(*s, v)
	return nil
}

type Result struct {
	Status  int           `json:"status"`
	Err     string        `json:"err,omitempty"`
	Latency time.Duration `json:"latency_ns"`
	Bytes   int64         `json:"bytes"`
}

type Summary struct {
	Target       string         `json:"target"`
	Method       string         `json:"method"`
	Total        int            `json:"total"`
	Success      int            `json:"success"`
	Errors       int            `json:"errors"`
	ErrorRatePct float64        `json:"error_rate_pct"`
	ElapsedMs    float64        `json:"elapsed_ms"`
	RPS          float64        `json:"rps"`
	LatencyMs    map[string]any `json:"latency_ms"`
	StatusCodes  map[int]int    `json:"status_codes"`
	BytesTotal   int64          `json:"bytes_total"`
	Timestamp    time.Time      `json:"timestamp"`
}

func main() {
	// ===== Flags =====
	target := flag.String("target", "http://localhost:8000/simulate", "target URL")
	method := flag.String("method", "POST", "HTTP method (GET, POST, ...)")
	n := flag.Int("n", 0, "total requests (mutually exclusive with -duration). If 0 and -duration=0 then defaults to 1")
	duration := flag.Duration("duration", 0, "test duration, e.g. 30s (overrides -n when >0)")
	concurrency := flag.Int("concurrency", 1, "number of concurrent workers")
	timeout := flag.Duration("timeout", 10*time.Second, "per-request timeout")
	body := flag.String("body", "", "raw request body (ignored if -body-file provided)")
	bodyFile := flag.String("body-file", "", "path to file for request body")
	progressEvery := flag.Duration("progress", 2*time.Second, "progress print interval; 0 to disable")
	outFile := flag.String("out", "", "write summary JSON to this file")
	var headers sliceFlag
	flag.Var(&headers, "H", `HTTP header, e.g. -H "Content-Type: application/json" (repeatable)`)

	flag.Parse()

	if *duration == 0 && *n == 0 {
		*n = 1 // default: smoke test 1 request
	}

	// ===== Prepare payload =====
	var payload []byte
	var err error
	if *bodyFile != "" {
		payload, err = os.ReadFile(*bodyFile)
		if err != nil {
			fatalf("failed to read body-file: %v", err)
		}
	} else if *body != "" {
		payload = []byte(*body)
	}

	// ===== HTTP client (pooling + timeouts) =====
	transport := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		DialContext: (&net.Dialer{
			Timeout:   30 * time.Second,
			KeepAlive: 30 * time.Second,
		}).DialContext,
		MaxIdleConns:          1000,
		MaxIdleConnsPerHost:   *concurrency,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
	}
	client := &http.Client{
		Transport: transport,
		Timeout:   *timeout,
	}

	// ===== Context & graceful shutdown =====
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	start := time.Now()

	var sent, succeeded, failed int64
	results := make([]Result, 0, max(*n, 1))
	var mu sync.Mutex

	// ===== Progress =====
	doneProgress := make(chan struct{})
	if *progressEvery > 0 {
		go func() {
			t := time.NewTicker(*progressEvery)
			defer t.Stop()
			for {
				select {
				case <-t.C:
					elapsed := time.Since(start).Seconds()
					total := atomic.LoadInt64(&sent)
					succ := atomic.LoadInt64(&succeeded)
					fail := atomic.LoadInt64(&failed)
					rps := 0.0
					if elapsed > 0 {
						rps = float64(total) / elapsed
					}
					fmt.Printf("[progress] sent=%d ok=%d err=%d rps=%.1f\n", total, succ, fail, rps)
				case <-ctx.Done():
					close(doneProgress)
					return
				}
			}
		}()
	} else {
		close(doneProgress)
	}

	// ===== Headers (parse once) =====
	headerMap := make(http.Header)
	for _, h := range headers {
		parts := strings.SplitN(h, ":", 2)
		if len(parts) != 2 {
			fatalf("invalid header: %q (use Key: Value)", h)
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		headerMap.Add(key, val)
	}

	// ===== Request executor =====
	doReq := func(ctx context.Context) Result {
		var bodyReader io.Reader
		if len(payload) > 0 && strings.ToUpper(*method) != "GET" {
			bodyReader = bytes.NewReader(payload)
		}
		req, err := http.NewRequestWithContext(ctx, *method, *target, bodyReader)
		if err != nil {
			return Result{Status: 0, Err: err.Error()}
		}
		for k, vs := range headerMap {
			for _, v := range vs {
				req.Header.Add(k, v)
			}
		}
		if req.Header.Get("Content-Type") == "" && bodyReader != nil {
			req.Header.Set("Content-Type", "application/json")
		}

		t0 := time.Now()
		resp, err := client.Do(req)
		lat := time.Since(t0)

		if err != nil {
			atomic.AddInt64(&failed, 1)
			return Result{Status: 0, Err: err.Error(), Latency: lat}
		}
		defer resp.Body.Close()
		written, _ := io.Copy(io.Discard, resp.Body)

		if resp.StatusCode >= 200 && resp.StatusCode < 400 {
			atomic.AddInt64(&succeeded, 1)
		} else {
			atomic.AddInt64(&failed, 1)
		}

		return Result{Status: resp.StatusCode, Latency: lat, Bytes: written}
	}

	// ===== Worker pool =====
	var wg sync.WaitGroup
	jobCh := make(chan struct{})

	for i := 0; i < *concurrency; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if *duration > 0 {
				deadline := time.Now().Add(*duration)
				for {
					select {
					case <-ctx.Done():
						return
					default:
						if time.Now().After(deadline) {
							return
						}
						atomic.AddInt64(&sent, 1)
						res := doReq(ctx)
						mu.Lock()
						results = append(results, res)
						mu.Unlock()
					}
				}
			} else {
				for range jobCh {
					select {
					case <-ctx.Done():
						return
					default:
					}
					atomic.AddInt64(&sent, 1)
					res := doReq(ctx)
					mu.Lock()
					results = append(results, res)
					mu.Unlock()
				}
			}
		}()
	}

	// producer
	if *duration == 0 {
		go func() {
			for i := 0; i < *n; i++ {
				jobCh <- struct{}{}
			}
			close(jobCh)
		}()
	}

	wg.Wait()
	cancel()
	<-doneProgress

	elapsed := time.Since(start)
	sum := makeSummary(*target, *method, results, elapsed)
	printSummary(sum)

	if *outFile != "" {
		if err := writeJSON(*outFile, sum); err != nil {
			fmt.Fprintf(os.Stderr, "write summary failed: %v\n", err)
		} else {
			fmt.Printf("Summary JSON written to: %s\n", *outFile)
		}
	}
}

func makeSummary(target, method string, results []Result, elapsed time.Duration) Summary {
	total := len(results)
	var ok, errCount int
	var bytesTotal int64
	lat := make([]time.Duration, 0, total)
	codeCount := map[int]int{}

	for _, r := range results {
		if r.Err != "" || r.Status < 200 || r.Status >= 400 {
			errCount++
		} else {
			ok++
		}
		if r.Status != 0 {
			codeCount[r.Status]++
		}
		bytesTotal += r.Bytes
		lat = append(lat, r.Latency)
	}

	sort.Slice(lat, func(i, j int) bool { return lat[i] < lat[j] })

	p50 := percentile(lat, 50)
	p90 := percentile(lat, 90)
	p99 := percentile(lat, 99)
	min, max, avg := time.Duration(0), time.Duration(0), time.Duration(0)
	if len(lat) > 0 {
		min = lat[0]
		max = lat[len(lat)-1]
		avg = time.Duration(int64(sumDur(lat)) / int64(len(lat)))
	}

	errRate := 0.0
	if total > 0 {
		errRate = 100 * float64(errCount) / float64(total)
	}

	rps := 0.0
	if elapsed.Seconds() > 0 {
		rps = float64(total) / elapsed.Seconds()
	}

	return Summary{
		Target:       target,
		Method:       method,
		Total:        total,
		Success:      ok,
		Errors:       errCount,
		ErrorRatePct: errRate,
		ElapsedMs:    float64(elapsed.Milliseconds()),
		RPS:          rps,
		LatencyMs: map[string]any{
			"min": float64(min.Microseconds()) / 1000.0,
			"p50": float64(p50.Microseconds()) / 1000.0,
			"p90": float64(p90.Microseconds()) / 1000.0,
			"p99": float64(p99.Microseconds()) / 1000.0,
			"max": float64(max.Microseconds()) / 1000.0,
			"avg": float64(avg.Microseconds()) / 1000.0,
		},
		StatusCodes: codeCount,
		BytesTotal:  bytesTotal,
		Timestamp:   time.Now(),
	}
}

func printSummary(s Summary) {
	fmt.Println("========== Summary ==========")
	fmt.Printf("Target:           %s\n", s.Target)
	fmt.Printf("Method:           %s\n", s.Method)
	fmt.Printf("Total requests:   %d\n", s.Total)
	fmt.Printf("Success:          %d\n", s.Success)
	fmt.Printf("Errors:           %d (%.2f%%)\n", s.Errors, s.ErrorRatePct)
	fmt.Printf("Elapsed:          %.0f ms\n", s.ElapsedMs)
	fmt.Printf("RPS:              %.2f\n", s.RPS)
	fmt.Println("Latency (ms):")
	fmt.Printf("  min: %.2f\n", s.LatencyMs["min"])
	fmt.Printf("  p50: %.2f\n", s.LatencyMs["p50"])
	fmt.Printf("  p90: %.2f\n", s.LatencyMs["p90"])
	fmt.Printf("  p99: %.2f\n", s.LatencyMs["p99"])
	fmt.Printf("  max: %.2f\n", s.LatencyMs["max"])
	fmt.Printf("  avg: %.2f\n", s.LatencyMs["avg"])
	fmt.Println("Status codes:")
	for c, cnt := range s.StatusCodes {
		fmt.Printf("  %d: %d\n", c, cnt)
	}
	fmt.Printf("Total bytes:      %d\n", s.BytesTotal)
	fmt.Println("=============================")
}

func writeJSON(path string, v any) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	enc.SetIndent("", "  ")
	return enc.Encode(v)
}

func percentile(durs []time.Duration, p int) time.Duration {
	if len(durs) == 0 {
		return 0
	}
	if p <= 0 {
		return durs[0]
	}
	if p >= 100 {
		return durs[len(durs)-1]
	}
	rank := (float64(p) / 100.0) * float64(len(durs))
	idx := int(math.Ceil(rank)) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(durs) {
		idx = len(durs) - 1
	}
	return durs[idx]
}

func sumDur(durs []time.Duration) time.Duration {
	var s time.Duration
	for _, d := range durs {
		s += d
	}
	return s
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func fatalf(format string, a ...any) {
	fmt.Fprintf(os.Stderr, format+"\n", a...)
	os.Exit(1)
}
