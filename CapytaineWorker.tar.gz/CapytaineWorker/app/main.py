import time
import logging
import subprocess
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, Any
from prometheus_client import (
    generate_latest,
    CONTENT_TYPE_LATEST,
    Counter,
    Histogram,
)
from fastapi.responses import Response

# Setup logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

app = FastAPI(title="Capytaine Worker", version="0.3.0")

# Prometheus metrics
REQUEST_COUNT = Counter(
    "capytaine_requests_total",
    "Total number of requests",
    ["endpoint", "http_status", "method"],
)
REQUEST_LATENCY = Histogram(
    "capytaine_request_duration_seconds",
    "Request latency in seconds",
    ["endpoint"],
)

class TestIn(BaseModel):
    iterations: int = Field(1, gt=0, description="Jumlah iterasi pytest dijalankan")
    test_file: str = Field("pytest/test_diffraction.py", description="File pytest yang dieksekusi")

class TestOut(BaseModel):
    status: str
    result: Dict[str, Any]

@app.get("/healthz")
def healthz():
    return {"status": "ok", "service": "capytaine-worker"}

@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.post("/start-test", response_model=TestOut)
def start_test(inp: TestIn):
    """Trigger pytest execution inside the worker"""
    start_time = time.perf_counter()
    try:
        results = []
        for i in range(inp.iterations):
            cmd = ["pytest", inp.test_file, "-q"]
            env = {
                **dict(**subprocess.os.environ),
                "OMP_NUM_THREADS": "16",
                "MKL_NUM_THREADS": "16",
            }
            proc = subprocess.run(cmd, capture_output=True, text=True, env=env)
            results.append({
                "iteration": i + 1,
                "exit_code": proc.returncode,
                "stdout": proc.stdout.strip(),
                "stderr": proc.stderr.strip(),
            })

        duration = time.perf_counter() - start_time

        REQUEST_COUNT.labels(endpoint="/start-test", http_status="200", method="POST").inc()
        REQUEST_LATENCY.labels(endpoint="/start-test").observe(duration)

        logging.info(
            f"[SUMMARY] Pytest file={inp.test_file} | Iterations={inp.iterations} | Duration={duration:.3f}s"
        )

        return {
            "status": "ok",
            "result": {
                "iterations": inp.iterations,
                "duration": duration,
                "results": results,
            },
        }

    except Exception as e:
        REQUEST_COUNT.labels(endpoint="/start-test", http_status="500", method="POST").inc()
        raise HTTPException(status_code=500, detail=str(e))
