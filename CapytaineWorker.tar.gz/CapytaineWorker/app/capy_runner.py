# app/capy_runner.py
from typing import Dict, Any
import capytaine as cpt
import numpy as np

def simulate_sphere(name: str, radius: float, heave_only: bool = True) -> Dict[str, Any]:
    """
    Bangun mesh sphere + siapkan DOF.
    Untuk langkah awal: kita kembalikan info mesh & dof saja (JSON-serializable).
    """
    # Bangun body sphere
    mesh = cpt.mesh_sphere(radius=radius, center=(0.0, 0.0, 0.0), resolution=(20, 20))
    body = cpt.FloatingBody(mesh=mesh, name=name)

    # Tambah DOF
    if heave_only:
        body.dofs = ["Heave"]   # hanya heave
    else:
        body.add_all_rigid_body_dofs()

    # Ambil koordinat vertices (versi lama: mesh.vertices)
    vertices = np.array(body.mesh.vertices)
    xmin, ymin, zmin = vertices.min(axis=0)
    xmax, ymax, zmax = vertices.max(axis=0)

    # Kembalikan ringkasan JSON
    info = {
        "name": body.name,
        "nb_faces": int(body.mesh.nb_faces),
        "nb_vertices": int(body.mesh.nb_vertices),
        "dofs": [str(d) for d in body.dofs],
        "bbox": {
            "xmin": float(xmin),
            "ymin": float(ymin),
            "zmin": float(zmin),
            "xmax": float(xmax),
            "ymax": float(ymax),
            "zmax": float(zmax),
        },
    }
    return info
