================
Developer manual
================

.. toctree::
   :maxdepth: 2

   installation.rst
   overview.rst
   contributing.rst
   testing.rst
   making_a_release.rst
   api/modules.rst
