=============
Theory manual
=============

.. toctree::
   :maxdepth: 2

   theory.rst
   bibliography.rst

.. glossary.rst
