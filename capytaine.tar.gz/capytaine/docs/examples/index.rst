===============
Example scripts
===============

.. toctree::
   :maxdepth: 2

   A_beginners_cookbook.rst
   B_intermediate_cookbook.rst
   C_advanced_cookbook.rst

.. validation.rst
