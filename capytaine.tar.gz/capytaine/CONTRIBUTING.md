# How to contribute

Thank you for your interest into Capytaine.

## Contact

The best place to report a bug or to propose an enhancement is the [issue
tracker](https://github.com/mancellin/capytaine/issues) of Capytaine's Github
repository.

The [discussion page](https://github.com/mancellin/capytaine/discussions) can
also be used to ask questions and submit ideas.

## Submitting changes

Pull requests are welcome.
See the [developer manual](https://capytaine.org/master/developer_manual) for
instructions.
